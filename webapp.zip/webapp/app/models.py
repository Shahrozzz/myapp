from django.db import models

# Create your models here.
class Student(models.Model):
    sname = models.CharField(max_length=100)
    sfname = models.CharField(max_length=100)
    sphone = models.IntegerField()
    scourse = models.CharField(max_length=100)
    scnic = models.IntegerField()
    saddress = models.CharField(max_length=100)
    sinstitute = models.CharField(max_length=100)
    scoursefee = models.IntegerField()
    sremaining = models.IntegerField(null=True)
    sambassador = models.CharField(max_length=100,null=True)
    payment = models.CharField(max_length=100)
    semail = models.EmailField(null=True)